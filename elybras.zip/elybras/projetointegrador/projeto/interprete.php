<?php
$estilo = "<link rel='stylesheet' href='css/interprete.css'> ";
include_once 'header_interprete.php';
?>
<body>
    <div class="corfundo">
        <h1 class="centro">Selecione o intérprete:</h1>
    </div>
    <br>
    <br>
    <br>
    <div class="grande">

        <div class="posicionamentodiv">
            <a href="agenda/perfil1.php"><img class="foto" src="agenda/img/foto1.jpg"></a>

            <ul>
                <a class="sublinhado" href="agenda/perfil1.php"><h2>Fernanda Meireles</h2></a>
                Meu nome é Fernanda Meireles, tenho 35 anos. Trabalho como intérprete há 15 anos e adoro ajudar as pessoas. Estou disponível para intermediar a comunicação entre paciente e médico.
            </ul>
        </div><br>

        <div class="posicionamentodiv">
            <a href="agenda/perfil2.php"><img class="foto" src="agenda/img/foto2.jpg"></a>
            <ul>
                <a class="sublinhado" href="agenda/perfil2.php"><h2>Juliana Pereira</h2></a>
                Olá, meu nome é Juliana. Sou formada em letras e em fonoaudiologia. Desde criança quis ajudar as pessoas, e hoje trabalho apoiando a inclusão de surdos e deficientes auditivos na área da saúde.
            </ul>
        </div><br>

        <div class="posicionamentodiv">
            <a href="agenda/perfil3.php"><img class="foto" src="agenda/img/foto3.jpg"></a>
            <ul>
                <a class="sublinhado" href="agenda/perfil3.php"><h2>Gabriela Oliveira</h2></a>
                Meu nome é Gabriela Oliveira e tenho 32 anos. Sou professora de libras em uma escola de ensino fundamental e estou sempre incentivando a inclusão para os meus alunos. Meu objetivo é transformar o mundo em um lugar melhor todos os dias!
            </ul>
        </div><br>

        <div class="posicionamentodiv">
            <a href="agenda/perfil4.php"><img class="foto" src="agenda/img/foto4.jpg"></a>
            <ul>
                <a class="sublinhado" href="agenda/perfil4.php"><h2>Igor Romanha</h2></a>
                Sou Igor Romanha e sou formado em letras e pós-graduado em libras. Meu sonho é ajudar as pessoas, e através dessa plataforma posso ajudar mais e mais pessoas com deficiência auditiva a terem acesso a melhor qualidade de vida.
            </ul>
        </div><br>

        <div class="posicionamentodiv">
            <a href="agenda/perfil5.php"><img class="foto" src="agenda/img/foto5.jpg"></a>
            <ul>
                <a class="sublinhado" href="agenda/perfil5.php"><h2>Mateus Silva</h2></a>
                Oi, me chamo Mateus. Sou estudante de libras e atualmente pretendo ajudar as pessoas com o conhecimento que venho adquirindo cada dia mais com o ambiente mais inclusivo.
            </ul>
        </div><br>
    </div>

</body>
</html>
