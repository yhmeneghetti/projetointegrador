<?php 
$estilo = "<link rel='stylesheet' href='css/resul.css'> ";
include_once '<header.php';
?>
<div class="centro">
    <h1>AGENDA SALVA COM SUCESSO!</h1>
</div>
<br><br>
<br><br>
<br><br>
<div class="centro">
    <img src="img/OK.JPG" width="15%">
</div>
</body>
</html>