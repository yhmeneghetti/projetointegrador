<!DOCTYPE html>
<html lang="pt">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="agenda/css/marcacao.css">
  <script src="agenda/js/marcacao.js" defer></script>
  <title>Cadastrar horários</title>
  <script type="text/javascript" src="agenda/css/marcacao.css"></script>
  <?php 
  $estilo = "<link rel='stylesheet' href='css/login.css'> ";
  include_once 'header_marcacao.php';
  ?>
</head>
<!---minhaFuncao permite que o calendário "ganhe vida" exibindo os meses e dias de qualquer ano---->
<body="minhaFuncao()">
<section class= "esquerda"> 
  <div class="conteudo">
    <div class="calendario">
      <header>
         <H2 id="mes">Julho</H2> <!-- Mostra o mês selecionado -->
            <a class="btn-ant" id="btn_ant"><</a> 
            <a class="btn-pro" id="btn_prev">></a>
         <!-- </div> -->
      </header>
      <table>
        <thead>
          <tr> <!--- Dias da semana -->
            <td>Dom</td>
            <td>Seg</td>
            <td>Ter</td>
            <td>Qua</td>
            <td>Qui</td>
            <td>Sex</td>
            <td>Sab</td>
          </tr>
        </thead>
        <tbody id="dias">
          <tr> <!--- SEMANA 1 -->
            <td class="mes-anterior">1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr> <!--- SEMANA 1 -->
            <td>1</td>
            <td>2</td>
            <td class="dia-atual event">3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr> <!--- SEMANA 2 -->
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td class="event">4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr> <!--- SEMANA 3 -->
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr> <!--- SEMANA 4 -->
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
          </tr>
          <tr> <!--- SEMANA 5 -->
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td class="proximo-mes">7</td>
          </tr>
        </tbody>
      </table>
</section>
    <div class="flutuar box">
      <form action="">
        <fieldset>
          <legend><b>DADOS DA CONSULTA</b></legend>
          <br>
          <div class="inputBox">
          <label for="nome">Intérprete:</label> 
          <input type="text" name="nome" id="nome" class ="inputUser" required>  
          </div><br><br>
          <legend><b>Selecione os horários em que está disponível</b></legend><br>
          <input type="checkbox" id="horario" name="horario" value="horario1">
          <label for="horario">06:00 - 07:00</label><br><br>
          <input type="checkbox" id="horario" name="horario" value="horario2">
          <label for="horario">08:00 - 09:00</label><br><br>
          <input type="checkbox" id="horario" name="horario" value="horario3">
          <label for="horario">10:00 - 11:00</label><br><br>
          <input type="checkbox" id="horario" name="horario" value="horario4">
          <label for="horario">12:00 - 13:00</label><br><br>
          <input type="checkbox" id="horario" name="horario" value="horario5">
          <label for="horario">14:00 - 15:00</label><br><br>
          <input type="checkbox" id="horario" name="horario" value="horario1">
          <label for="horario">16:00 - 17:00</label><br><br>
          <input type="checkbox" id="horario" name="horario" value="horario1">
          <label for="horario">18:00 - 19:00</label><br><br><br>
          <div class = "centro">
          <a href="agenda/resul.php"><input class="botao" type="submit" name="submit" id="submit"></input></a>
          </div>       
        </fieldset>
    </div>
    </div>
</div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<footer>
  <h2 id="ano">2023</h2>
</footer>
</body>
</html>
