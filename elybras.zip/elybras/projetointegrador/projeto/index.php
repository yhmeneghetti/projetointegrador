<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>elibras interprete</title>
    <link rel="shortcut icon" href="icone.ico" type="image/x-icon">
    <link rel="stylesheet" href="agenda/css/inicial.css" />
    <meta nome= "viewport" content="width=device-width, initiel-scale=1.0, maximum-scale=1.0">
</head>

<body>
    <header>
        <div class="center">
            <div class="logo"><img src="agenda/img/logoo.png" alt=""></div>
            <div class="menu">
                <a href="login.php">Login</a>
                <a href="quemsomos.php">Sobre</a>
                <a href="cadastro.php">Cadastro</a>
            </div>
        </div>        
    </header>

    

    <section class="sobre">
        <div class="extras">
            <img src="agenda/img/letra.png" alt="Letra" >
        </div>
        <div class="center">
            <div class="texto">
                <h1>Sejam bem-vindos a <br> <span style="color: #228acb ;">ELYBRAS  </span> interprete</h1>
                <p>Fortaleça laços e aumente a fidelidade dos seus clientes à sua 
                    capacidade de ajudar o próximo. Com intérprete <span style="color: #228acb ;">ELYBRAS  </span>, você mantém seu 
                    negócio sempre presente na memória do consumidor, além de poder oferecer um passo maior 
                    para inclusão, seja bem vindo (a) a <span style="color: #228acb ;">ELYBRAS  </span>!
                </p>
                
            <a href="login.php"><button>ACESSE AQUI</button></a
            </div>
        </div>
    </section>
    
    
</body>
</html>