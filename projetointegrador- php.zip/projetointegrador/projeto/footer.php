
<footer class="p-4 bg-dark text-light text-align:end fixed-bottom">TODOS OS DIREITOS RESERVADOS</footer>

</body>
</html>