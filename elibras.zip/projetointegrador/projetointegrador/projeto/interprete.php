<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>selecionar Intérprete</title>
    <link rel="stylesheet" href="agenda/css/interprete.css">
</head>
<body>
    <header>
        <nav> <!---- Menu ---->
            <div class="log"><img class ="logo" src = "agenda/img/elibra-removebg-preview.png" width="120" height="105"></div>
            <ul class="navlist"> 
                <li><a href="index.html">Home</a></li> 
                <li><a href="login.html">Login</a></li>
                <li><a href="cadastro.html">Cadastro</a></li>     
                <li><a href="quemsomos.html">Sobre</a></li>  
            </ul> 
        </nav>
    </header>   
    <div class = "corfundo">
        <h1 class="centro">Selecione o intérprete:</h1> <!----Perfis de intérprete-->    
    </div>
    <br>
    <br>
    <br>  
    <div class="posicionamentodiv"> <!--Perfil 1---->
        <a href="agenda/perfil1.php"><img  class = "foto" src = "agenda/img/foto1.jpg"></a>
        <ul>
            <a class = "sublinhado" href="agenda/perfil1.php"><h2>Fernanda Meireles</h2></a>Meu nome é Fernanda Meireles, tenho 35 anos. Trabalho como intérprete há 15 anos e adoro ajudar as pesssoas. Estou disponível para intermediar a comunicação entre paciente e médico.
        </ul>
    </div><br>

    <div class="posicionamentodiv"><!--Perfil 2 ---->
        <a href="agenda/perfil2.php"><img  class = "foto" src = "agenda/img/foto2.jpg"></a>
        <ul>
            <a class = "sublinhado" href="agenda/perfil2.php"><h2>Juliana Pereira</h2></a>Olá, meu nome é Juliana. Sou formada em letras e em fonoaudiologia. Desde criança quis ajudar as pesssoas, e hoje trabalho apoiando a inclusão de surdos e deficientes auditivos na área da saúde.
        </ul>
    </div><br>

    <div class="posicionamentodiv"><!--Perfil 3 ---->
        <a href="agenda/perfil3.php"><img  class = "foto" src = "agenda/img/foto3.jpg"></a>
        <ul>
            <a class = "sublinhado" href="agenda/perfil3.php"><h2>Gabriela Oliveira</h2></a>Meu nome é Gabriela Oliveira e tenho 32 anos. Sou professora de libras em uma escola de ensino fundamental e estou sempre incentivando a inclusão para os meus alunos. Meu objetivo é transformar o mundo em um lugar melhor todos os dias! </ul>
    </div><br>

    <div class="posicionamentodiv"><!--Perfil 4---->
        <a href="agenda/perfil4.php"><img  class = "foto" src = "agenda/img/foto4.jpg"></a>
        <ul>
        <a class = "sublinhado" href="agenda/perfil4.php"><h2>Igor Romanha</h2></a>Sou Igor Romanha e sou formado em letras e pós-graduado em libras. Meu sonho é ajudar as pessoas, e através dessa plataforma posso ajudar mais e mais pessoas com deficiência auditiva a terem acesso a melhor qualidade de vida.</ul>
    </div><br>

    <div class="posicionamentodiv"><!--Perfil 5---->
        <a href="agenda/perfil5.php"><img  class = "foto" src = "agenda/img/foto5.jpg"></a>
        <ul>
            <a class = "sublinhado" href="agenda/perfil5.php"><h2>Mateus Silva</h2></a>Oi, me chamo Mateus. Sou estudante de libras e atualmente pretendo ajudar as pessoas com o conhecimento que venho adquirindo cada dia mais com o ambiente mais incusivo.</ul>
    </div><br>

</body>
</html>