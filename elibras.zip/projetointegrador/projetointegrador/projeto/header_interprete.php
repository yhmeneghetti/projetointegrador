<!-- Menú para página do intérprete -->
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    
    <?php echo $estilo?>   
    
</head>
<body>
    <header> 
        <nav>
            <div class="log"><img class ="logo" src = "agenda/img/elibra-removebg-preview.png" width="120" height="105"></div>
            <ul class="navlist"> 
                <li><a href="index.php">Home</a></li> 
                <li><a href="interprete.php">Selecionar Intérprete</a></li>   
                <li><a href="quemsomos.php">Sobre</a></li>  
                <li><a href="marcacao.php">Cadastrar horários</a></li>
            </ul> 
            </nav>
    </header>