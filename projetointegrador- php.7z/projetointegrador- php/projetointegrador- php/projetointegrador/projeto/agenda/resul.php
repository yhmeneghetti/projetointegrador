<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitação Confirmada</title>
    <link rel="stylesheet" href="css/resul.css">
</head>
<body>
<div class="centro">
    <h1>AGENDA SALVA COM SUCESSO!</h1>
</div>
<br><br>
<br><br>
<br><br>
<div class="centro">
    <img src="img/OK.JPG" width="15%">
</div>
</body>
</html>