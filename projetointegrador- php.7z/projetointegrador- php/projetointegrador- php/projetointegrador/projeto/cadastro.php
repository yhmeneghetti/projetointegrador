<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/cadastro.css">
    
</head>
<body>
    
    <div class="login-interprete">
        <h1>Cadastro</h1>
        <p>Para prosseguir informe os dados abaixo</p>
        <div class="coluna" >
            <div CLASS="tamanho">

                <div >
                    <label for="nome">Nome completo</label>
                    <br><br>
                    <input type="text" id="nome"placeholder="Nome completo">
                    <br><br>
                </div>

                <div>
                    <label for="email">Email</label>
                    <br>
                    <p>Utilize seu melhor email</p>
                    <input type="emai" id="email" placeholder="Digite seu email">
                    <br><br>
                </div>

                <div>
                    <label type="tel">Telefone celular</label>
                    <br>
                    <p>Digite o DDD também</p>
                    <input for="tel" id="tel" placeholder="(99) 99999-9999">
                <br><br>
                </div>

                <div></div>
                <label for="data_nasc">Data de nascimento</label>
                <br><br>
                <input type="date" id="data_nasc" name="data">
                <br><br>

            </div>
            
            <div CLASS="tamanho">
                <label for="cpf">CPF</label>
                <br><br>
                <input type="text" id="cpf" placeholder="000.000.000.00">
                <br><br>
                <label for="login">Defina seu login</label>
                <p>Utilize no mínimo 6 digitos</p>
                <input type="text" id="login" placeholder="Digite seu novo login">
                <br><br>
                <label for="senha">Defina sua senha</label>
                <p>Utilize no mínimo 6 dígitos</p>
                <input type="password" id="senha" name="senha" placeholder="Digite sua senha">
                <br><br>
                <label for="confirme-senha">Confirme sua senha</label>
                <br><br>
                <input type="password" id="confirme-senha" name="confirme-senha" placeholder="Digite sua senha">
            </div>
        </div>
        <div class="div1">
            <br>
            <a href="login.php"><button>Acessar</button></a>
        </div>
    </div>
    
</head>
<body>
    
</body>
</html>