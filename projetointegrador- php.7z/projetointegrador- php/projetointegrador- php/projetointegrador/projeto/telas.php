<?php
    $estilo = "<link rel='stylesheet' href='css/index.css'> ";
    include_once 'header.php';
?>

        <div class="leiacessibilidade">
            <h1>Lei Nº 10.098</h1>
        <p>
            Art 1º Esta Lei estabelece normas gerais e critérios básicos para a promoção da 
            acessibilidade das pessoas portadoras de deficiências ou com mobilidade reduzida, 
            mediante a supressão de barreiras e de obstáculos nas vias e espaços públicos, 
            no mobiliário urbano, na construção e reforma de edifícios e nos meios de transporte e 
            de comunicação.
        </p>
        </div>
</body>
</html>