<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendamento</title>
    <link rel="stylesheet" href="css/agd.css">
</head>
<body>
    <div class = "corfundo">
		<h1>Usuário, escolha a agenda disponível para o dia xx/xx/xxxx:</h1>
</div>
    <h2 class="centro">Mateus Silva</h2>
    <div class="imagem">
        <img src="img/foto5.jpg" width="100%"></a><br><br>
    </div>
	<section class="flex">
		<div>
			<a href="pagina_confirmacao.php"><button>8:00</button></a>
		</div>
		<div>
			<a href="pagina_confirmacao.php"><button>10:00</button></a>
		</div>
		<div>
			<a href="pagina_confirmacao.php"><button>13:00</button></a>
		</div>
		<div>
			<a href="pagina_confirmacao.php"><button>14:30</button></a>
		</div>
		<div>
			<a href="pagina_confirmacao.php"><button>18:00</button></a>
		</div>
		<div>
			<a href="pagina_confirmacao.php"><button>20:00</button></a>
		</div>

	</section>
</body>
</html>