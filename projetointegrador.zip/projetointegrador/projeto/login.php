<?php 
$estilo = "<link rel='stylesheet' href='agenda/css/login.css'> ";
include_once 'header.php';
?>
        
<body class="fundologin">
    <div class="login-interprete">
        <h1>Login</h1>
        <input type="text" placeholder="Login">
        <br><br>
        <input type="password" placeholder="Senha">
        <br><br>
        <a href="interprete.php"><button>Acessar</button></a>
    </div>
</body>
</html>
