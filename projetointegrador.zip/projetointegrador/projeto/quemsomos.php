<?php 
$estilo = "<link rel='stylesheet' href='agenda/css/quemsomos.css'> ";
include_once 'header.php';
?>

        <div class="elybras">
            <h1>QUEM SOMOS?</h1>
            <P>
                A ELYBRAS foi pensada para amparar e dar a devida acessibilidade a quem possui deficiência 
                auditiva, com principal objetivo e visando a prioridade em consultas médicas com auxílio de um 
                intérprete disponibilizado pelo hospital.A princípio foi presenciado em uma palestra dada em uma
                escola de ensino médio localizada em Vitória-ES por um professor surdo-mudo sendo interpretado 
                através da linguagem de sinais, o mesmo relatou suas dificuldades na sociedade e a falta de 
                auxílio para necessidades básicas e necessárias para um cidadão, em síntese citou quando foi a 
                um hospital e o mesmo não o fornecia o intérprete para ele se comunicar com o médico em sua 
                consulta, caso fosse de urgência o mesmo teria de esperar um tempo até que o hospital conseguisse
                contato com algum intérprete especialista.Logo foi notado a necessidade de muitas pessoas em se 
                ter acessibilidade em locais como hospitais, segundo pesquisas no Brasil, cerca de 5% da 
                população é surda e, parte dela usa a Libras como auxílio para comunicação. De acordo com 
                dados do IBGE, esse número representa 10 milhões de pessoas, sendo que 2,7 milhões não ouvem nada. 
            </P>
        </div>
</body>
</html>